#ifndef SIPHASH_H
#define SIPHASH_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

/* Encryption key is expected to be 128-bits */

extern int siphash(const uint8_t *in, const size_t inlen, const uint8_t *encryptionKey,
	uint8_t *out, const size_t outlen);

extern int halfsiphash(const uint8_t *in, const size_t inlen, const uint8_t *encryptionKey,
	uint8_t *out, const size_t outlen);

#ifdef __cplusplus
}
#endif

#endif
